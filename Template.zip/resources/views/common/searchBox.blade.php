<div class="row justify-content-between">
    <div class="col-lg-4 col-md-4 col-sm-12">
        <div class="input-group mb-4">
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text input-gp">
                        <i class="fa fa-search"></i>
                    </span>
                </div>
                <input class="form-control" type="text" wire:model="search" placeholder="Buscar" onclick="this.select()">
            </div>
        </div>
    </div>
</div>
